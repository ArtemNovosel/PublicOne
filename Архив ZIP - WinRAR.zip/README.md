# PublicOne
Задание 9.2.4
